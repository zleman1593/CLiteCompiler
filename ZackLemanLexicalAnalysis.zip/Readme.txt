Readme:

If using an IDE:————————————————————————————————————————————————————————


In the Program class in the line:
 	parser.start("/Users/zackleman/Downloads/input.c");
 	
 	
 Replace the string  with the location of the .c file to parse.
 Then run the program using the eclipse IDE or another IDE.
 
If using the Command Line:————————————————————————————————————————————————————————

 
   Run from the terminal with a single argument (A string of the file location) such as: 
  
    	java Program /Users/zackleman/Downloads/input.c



(If needed recompile Program.java)

