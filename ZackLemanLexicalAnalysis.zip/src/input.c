int main
{
 int x = 0;
 x = x + 10;
 print x;
 return x;
}